"""Bounded, inspectable connections learned from action/sensory histories."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math

from .world import Command, MAX_DELAY, Percept


def clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def solve(matrix: list[list[float]], rhs: list[float]) -> list[float]:
    """Small positive-definite ridge system; partial pivoting, no dependency."""
    rows = [row[:] + [value] for row, value in zip(matrix, rhs)]
    n = len(rhs)
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(rows[r][col]))
        rows[col], rows[pivot] = rows[pivot], rows[col]
        scale = rows[col][col]
        if abs(scale) < 1e-12:
            return [0.0] * n
        rows[col] = [x / scale for x in rows[col]]
        for row in range(n):
            if row == col:
                continue
            scale = rows[row][col]
            rows[row] = [a - scale * b for a, b in zip(rows[row], rows[col])]
    return [row[-1] for row in rows]


class SensorRegression:
    """Exponentially weighted linear response to all ports at four candidate lags."""

    def __init__(self):
        self.gram: list[list[float]] = []
        self.rhs: list[float] = []
        self.weights: list[float] = []
        self.square = 0.0
        self.mass = 0.0
        self.residual = 0.01
        self.count = 0

    def expand(self, n: int) -> None:
        old = len(self.rhs)
        for row in self.gram:
            row.extend([0.0] * (n - old))
        self.gram.extend([[0.0] * n for _ in range(n - old)])
        self.rhs.extend([0.0] * (n - old))
        self.weights.extend([0.0] * (n - old))

    def learn(self, features: list[float], difference: float) -> None:
        self.expand(len(features))
        decay = 0.94
        self.count += 1
        self.mass = decay * self.mass + 1
        self.square = decay * self.square + difference * difference
        for i, x in enumerate(features):
            self.rhs[i] = decay * self.rhs[i] + x * difference
            for j, y in enumerate(features):
                self.gram[i][j] = decay * self.gram[i][j] + x * y
        matrix = [[value + (0.003 if i == j else 0) for j, value in enumerate(row)]
                  for i, row in enumerate(self.gram)]
        self.weights = [clip(w, -0.8, 0.8) for w in solve(matrix, self.rhs)]
        error = self.square - 2 * sum(w * r for w, r in zip(self.weights, self.rhs))
        error += sum(self.weights[i] * self.weights[j] * self.gram[i][j]
                     for i in range(len(features)) for j in range(len(features)))
        self.residual = max(1e-6, error / max(1, self.mass))


@dataclass
class Connection:
    port: str
    sensor: str
    delay: int
    gain: float
    confidence: float
    lag_weights: list[float]


class Perspective:
    """The shared model consumed by ownership, attention, diagnostics and planning.

    Topology is fixed to port -> sensory-change edges; attachment appends ports
    and sensors. Numerical changes are bounded; it does not rewrite source code.
    """

    def __init__(self):
        self.ports: list[str] = []
        self.regressions: dict[str, SensorRegression] = {}
        self.history: list[Command] = []
        self.attention: dict[str, float] = {}
        self.ownership: dict[str, float] = {}
        self.body_members: list[str] = []
        self.frozen = False
        self.revision = 0

    def register(self, percept: Percept) -> None:
        for port in percept.ports:
            if port not in self.ports:
                self.ports.append(port)
        for sensor in percept.signals:
            self.regressions.setdefault(sensor, SensorRegression())
        for regression in self.regressions.values():
            regression.expand(1 + len(self.ports) * (MAX_DELAY + 1))

    def features(self, command: Command) -> list[float]:
        history = [command] + list(reversed(self.history[-MAX_DELAY:]))
        # An independent drift term separates constant world motion from effects
        # of commands. It is a nuisance predictor, not a motor connection.
        return [1.0] + [history[lag].amount if lag < len(history) and history[lag].port == port else 0.0
                for port in self.ports for lag in range(MAX_DELAY + 1)]

    def predict(self, command: Command, sensor: str) -> float:
        return sum(a * b for a, b in zip(self.features(command), self.regressions[sensor].weights))

    def learn(self, before: Percept, command: Command, after: Percept) -> dict:
        self.register(after)
        features = self.features(command)
        changes = {}
        if not self.frozen:
            for sensor in before.signals.keys() & after.signals.keys():
                if sensor == before.target_channel and before.object_id != after.object_id:
                    continue
                regression = self.regressions[sensor]
                old = regression.weights[:]
                regression.learn(features, after.signals[sensor] - before.signals[sensor])
                if max((abs(a - b) for a, b in zip(old, regression.weights)), default=0) > 1e-8:
                    changes[sensor] = {"before": old, "after": regression.weights[:]}
            self.revision += 1
        self.history.append(command)
        self.history = self.history[-MAX_DELAY:]
        self.refresh_attention(after.target_channel)
        return changes

    def connection(self, port: str, sensor: str) -> Connection:
        index = 1 + self.ports.index(port) * (MAX_DELAY + 1)
        reg = self.regressions[sensor]
        weights = reg.weights[index:index + MAX_DELAY + 1]
        delay = max(range(len(weights)), key=lambda lag: abs(weights[lag]))
        gain = weights[delay]
        total = sum(abs(w) for w in weights) + 1e-9
        confidence = clip(abs(gain) / total * min(1.0, reg.count / 18) *
                          abs(gain) / (abs(gain) + math.sqrt(reg.residual)), 0, 1)
        return Connection(port, sensor, delay, gain, confidence, weights[:])

    def refresh_attention(self, target_channel: str) -> None:
        if self.frozen:
            return
        scores = {}
        for sensor, reg in self.regressions.items():
            edges = [self.connection(port, sensor) for port in self.ports]
            owned = max((abs(e.gain) * e.confidence for e in edges), default=0)
            self.ownership[sensor] = clip(owned / 0.10, 0, 1)
            if sensor != target_channel:
                scores[sensor] = owned / (0.003 + math.sqrt(reg.residual))
        normalizer = sum(scores.values()) or 1
        self.attention = {s: value / normalizer for s, value in scores.items()}
        # Retain learned identity through temporary loss of controllability.
        # Membership and momentary influence are distinct internal estimates.
        if self.ports and len(self.body_members) < 2:
            candidates = sorted(scores, key=scores.get, reverse=True)
            for sensor in candidates:
                edge = self.connection(self.ports[0], sensor)
                if sensor not in self.body_members and self.regressions[sensor].count >= 18 and edge.confidence > 0.55 and abs(edge.gain) > 0.04:
                    self.body_members.append(sensor)
                if len(self.body_members) == 2:
                    break

    def body_channels(self, target_channel: str) -> list[str]:
        # The first discovered effector supplies the reference body boundary;
        # a tool-specific sensor is an extension, not a second absolute position.
        if not self.ports:
            return []
        if self.body_members:
            return sorted(self.body_members, key=lambda s: self.attention.get(s, 0), reverse=True)
        candidates = [s for s in self.regressions if s != target_channel and
                      abs(self.connection(self.ports[0], s).gain) > 0.035 and
                      self.connection(self.ports[0], s).confidence > 0.32]
        return sorted(candidates, key=lambda s: self.attention.get(s, 0), reverse=True)[:2]

    def estimate_body(self, percept: Percept, disconnected: bool = False) -> tuple[float, str | None]:
        channels = [s for s in self.body_channels(percept.target_channel) if s in percept.signals]
        if not channels:
            return 0.0, None
        if disconnected:
            return sum(percept.signals[s] for s in channels) / len(channels), channels[0]
        sensor = channels[0]
        return percept.signals[sensor], sensor

    def export(self) -> dict:
        return {"revision": self.revision, "frozen": self.frozen,
                "body_members": list(self.body_members),
                "connections": [asdict(self.connection(p, s)) for p in self.ports for s in self.regressions],
                "attention": dict(self.attention), "ownership": dict(self.ownership),
                "prediction_error_variance": {s: r.residual for s, r in self.regressions.items()}}

    def state(self) -> dict:
        return {**self.__dict__, "regressions": {s: r.__dict__ for s, r in self.regressions.items()},
                "history": [asdict(c) for c in self.history]}

    @classmethod
    def restore(cls, state: dict) -> "Perspective":
        perspective = cls()
        perspective.__dict__.update(state)
        perspective.regressions = {}
        for sensor, data in state["regressions"].items():
            regression = SensorRegression()
            regression.__dict__.update(data)
            perspective.regressions[sensor] = regression
        perspective.history = [Command(**c) for c in state["history"]]
        return perspective
