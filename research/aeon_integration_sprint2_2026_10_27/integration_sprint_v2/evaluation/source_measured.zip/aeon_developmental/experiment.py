"""Evaluator-only orchestration, hash-chained evidence and paired comparisons."""
from __future__ import annotations

from dataclasses import asdict
import hashlib
import gzip
import json
import math
from pathlib import Path
import statistics

from .entity import CONDITIONS, DevelopmentalEntity
from .model import Perspective
from .world import ArmWorld, Command, MAX_DELAY

SEEDS = (17, 29, 41, 53, 67, 79, 97, 109)
SCENARIOS = ("delay", "sensor_fault", "world_shift", "action_failure", "tool")
PROTOCOL_PATH = Path(__file__).with_name("PROTOCOL.md")


def canonical(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value: object) -> str:
    return hashlib.sha256(canonical(value).encode()).hexdigest()


class Audit:
    """Local tamper evidence; neither a signed nor externally anchored ledger."""

    def __init__(self, path: Path | None = None):
        self.head, self.count, self.path = "0" * 64, 0, path
        if path:
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists():
                raise FileExistsError(f"Refusing to overwrite trace: {path}")

    def append(self, event: dict) -> None:
        record = {"index": self.count, "previous": self.head, "event": event}
        record["hash"] = digest(record)
        if self.path:
            with self.path.open("a", encoding="utf-8") as stream:
                stream.write(canonical(record) + "\n")
        self.count += 1
        self.head = record["hash"]


def verify_trace(path: Path, expected_head: str | None = None) -> dict:
    head, count = "0" * 64, 0
    try:
        opener = gzip.open if path.suffix == ".gz" else open
        with opener(path, "rt", encoding="utf-8") as stream:
            for line in stream:
                record = json.loads(line)
                stored = record.pop("hash")
                if record["index"] != count or record["previous"] != head or digest(record) != stored:
                    return {"valid": False, "records": count, "reason": "chain mismatch"}
                count += 1
                head = stored
    except (OSError, ValueError, KeyError, TypeError, EOFError) as error:
        return {"valid": False, "records": count, "reason": str(error)}
    return {"valid": expected_head is None or head == expected_head,
            "records": count, "head": head, "anchored_to_expected_head": expected_head is not None}


def train_donor(seed: int) -> Perspective:
    world, entity = ArmWorld(seed, donor=True), DevelopmentalEntity(seed)
    for _ in range(world.shift):
        decision = entity.decide(world.observe(), world.observe)
        world.step(Command(**decision["command"]))
        entity.learn(world.observe())
    return Perspective.restore(json.loads(canonical(entity.model.state())))


def one_shot_transfer(source_world: ArmWorld, source_entity: DevelopmentalEntity) -> dict:
    """Cloned feasible catch with motor learning frozen and no prior catch failure."""
    world = ArmWorld.restore(json.loads(canonical(source_world.state())))
    entity = DevelopmentalEntity.restore(json.loads(canonical(source_entity.state())))
    entity.model.frozen = True
    for _ in range(MAX_DELAY + 1):
        entity.passive_prediction(world.observe())
        world.step(Command())
        entity.learn(world.observe())
    world.object_id, world.velocity = "transfer-probe", 0.025
    world.target = world.body + 0.035
    for _ in range(2):
        entity.passive_prediction(world.observe())
        world.step(Command())
        entity.learn(world.observe())
    entity.probes.clear()
    decision = entity.decide(world.observe(), world.observe)
    command = Command(**decision["command"])
    horizon = world.delay + 1 if command.port == world.motor else 1
    for index in range(horizon):
        world.step(command if index == 0 else Command())
    error = abs(world.body - world.target)
    return {"error": error, "success": error <= 0.08, "horizon": horizon,
            "first_command": decision, "motor_learning_disabled": True,
            "passive_motion_frames": 2, "pending_command_drain_steps": MAX_DELAY + 1,
            "model_revision_before": source_entity.model.revision,
            "model_revision_after": entity.model.revision}


class ResearchRun:
    def __init__(self, seed: int = 17, scenario: str = "delay", condition: str = "full",
                 trace: Path | None = None):
        self.world, self.entity = ArmWorld(seed, scenario), DevelopmentalEntity(seed, condition)
        self.audit = Audit(trace)
        self.metrics: list[dict] = []
        self.protocol_hash = hashlib.sha256(PROTOCOL_PATH.read_bytes()).hexdigest()
        self.audit.append({"type": "genesis", "seed": seed, "scenario": scenario,
                           "condition": condition, "protocol_sha256": self.protocol_hash})
        self.transfer_probe_result: dict | None = None

    def cycle(self) -> dict:
        world, entity = self.world, self.entity
        if world.tick == world.shift:
            entity.intervene(train_donor(world.seed) if entity.condition == "foreign_predictions" else None)
            self.audit.append({"type": "research_intervention", "tick": world.tick,
                               "configuration": entity.condition})
        if world.tick == world.transfer:
            self.transfer_probe_result = one_shot_transfer(world, entity)
            self.audit.append({"type": "transfer_probe", "result": self.transfer_probe_result})
        decision = entity.decide(world.observe(), world.observe)
        # Prediction is committed BEFORE the motor command reaches the world.
        self.audit.append({"type": "decision", "tick": world.tick, "actor": decision})
        body_before = world.body
        world.step(Command(**decision["command"]))
        after = world.observe()
        learning = entity.learn(after)
        task_valid = decision["situation"]["object_id"] == after.object_id
        sensor = decision["situation"]["body_channel"]
        estimated_delay = entity.model.connection(world.motor, sensor).delay if sensor else None
        metric = {"tick": world.tick, "position_error": abs(world.body - world.target) if task_valid else None,
                  "success": abs(world.body - world.target) <= 0.08 if task_valid else None,
                  "task_feedback_valid": task_valid,
                  "lag_error": abs(estimated_delay - world.delay) if estimated_delay is not None else None,
                  "estimated_delay": estimated_delay,
                  "body_estimate_error": abs(decision["situation"]["body_estimate"] - body_before),
                  "cause": max(entity.hypotheses, key=entity.hypotheses.get),
                  "diagnostic": "alternative_response_traces" in decision["prediction"], "cost": decision["cost"]}
        self.metrics.append(metric)
        self.audit.append({"type": "outcome", "tick": world.tick, "percept": asdict(after),
                           "learning": learning, "evaluator_only": {"truth": world.truth(), "metric": metric}})
        return {"decision": decision, "learning": learning, "metric": metric}

    def run(self, until: int = 240) -> dict:
        if until < self.world.tick:
            raise ValueError("until precedes checkpoint")
        while self.world.tick < until:
            self.cycle()
        return self.summary()

    def summary(self) -> dict:
        world, entity = self.world, self.entity
        adaptation = [m for m in self.metrics if world.shift < m["tick"] <= world.transfer]
        transfer = [m for m in self.metrics if m["tick"] > world.transfer]
        def mean(rows, name):
            values = [r[name] for r in rows if r[name] is not None]
            return statistics.mean(values) if values else None
        expected = {"delay": "action_delayed", "sensor_fault": "sensor_unreliable",
                    "world_shift": "world_changed", "action_failure": "action_failed"}.get(world.scenario)
        primary = entity.model.body_channels(world.target_channel)
        tool_edges = [asdict(entity.model.connection(world.tool, s)) for s in primary] if world.tool in entity.model.ports else []
        return {"seed": world.seed, "scenario": world.scenario, "condition": entity.condition,
                "ticks": world.tick, "protocol_sha256": self.protocol_hash,
                "metrics": {"adaptation_error": mean(adaptation, "position_error"),
                            "late_adaptation_error": mean(adaptation[-24:], "position_error"),
                            "late_lag_error": mean(adaptation[-24:], "lag_error"),
                            "transfer_error": mean(transfer, "position_error"),
                            "transfer_success_rate": mean(transfer, "success"),
                            "body_estimate_error": mean(adaptation, "body_estimate_error"),
                            "diagnostic_accuracy_early": statistics.mean(m["cause"] == expected for m in adaptation[:24]) if adaptation and expected else None,
                            "diagnostic_accuracy_adaptation": statistics.mean(m["cause"] == expected for m in adaptation) if adaptation and expected else None,
                            "diagnosis_latency": next((m["tick"] - world.shift for m in adaptation if m["cause"] == expected), None) if expected else None,
                            "diagnostic_pulses": sum(m["diagnostic"] for m in adaptation),
                            "cognitive_cost": entity.total_cost,
                            "one_shot_error": self.transfer_probe_result["error"] if self.transfer_probe_result else None,
                            "one_shot_success": self.transfer_probe_result["success"] if self.transfer_probe_result else None},
                "transfer_probe": self.transfer_probe_result, "operations": dict(entity.operation_counts),
                "final_perspective": entity.model.export(), "tool_body_connections": tool_edges,
                "audit": {"records": self.audit.count, "head": self.audit.head}, "state_digest": digest(self.state())}

    def state(self) -> dict:
        return {"version": 1, "world": self.world.state(), "entity": self.entity.state(),
                "metrics": self.metrics, "transfer_probe_result": self.transfer_probe_result,
                "protocol_hash": self.protocol_hash, "audit": {"head": self.audit.head, "count": self.audit.count}}

    def checkpoint(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = self.state()
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps({"payload": payload, "sha256": digest(payload)}, indent=2), encoding="utf-8")
        temporary.replace(path)

    @classmethod
    def restore(cls, path: Path, trace: Path | None = None) -> "ResearchRun":
        snapshot = json.loads(path.read_text(encoding="utf-8"))
        state = snapshot["payload"]
        if digest(state) != snapshot["sha256"] or state["version"] != 1:
            raise ValueError("Invalid checkpoint")
        if state["protocol_hash"] != hashlib.sha256(PROTOCOL_PATH.read_bytes()).hexdigest():
            raise ValueError("Checkpoint protocol differs from current protocol")
        run = cls.__new__(cls)
        run.world, run.entity = ArmWorld.restore(state["world"]), DevelopmentalEntity.restore(state["entity"])
        run.metrics, run.transfer_probe_result = state["metrics"], state["transfer_probe_result"]
        run.protocol_hash, run.audit = state["protocol_hash"], Audit(trace)
        run.audit.append({"type": "resume", "predecessor": state["audit"], "checkpoint_sha256": snapshot["sha256"]})
        return run


def paired_interval(differences: list[float]) -> dict:
    mean = statistics.mean(differences)
    se = statistics.stdev(differences) / math.sqrt(len(differences)) if len(differences) > 1 else 0
    critical = {2: 12.706, 3: 4.303, 4: 3.182, 5: 2.776, 6: 2.571, 7: 2.447, 8: 2.365}.get(
        len(differences), 2.1 if len(differences) < 30 else 1.96)
    return {"mean": mean, "approx_95_interval": [mean - critical * se, mean + critical * se],
            "pairs": len(differences), "method": "paired t descriptive interval; no multiplicity correction"}


def compare(seeds=SEEDS, scenarios=SCENARIOS, conditions=CONDITIONS, progress=None,
            trace_root: Path | None = None) -> dict:
    if not seeds or not scenarios or not conditions or len(set(seeds)) != len(seeds):
        raise ValueError("Nonempty selections and unique seeds required")
    rows = []
    for scenario in scenarios:
        for seed in seeds:
            for condition in conditions:
                path = trace_root / scenario / str(seed) / f"{condition}.jsonl" if trace_root else None
                result = ResearchRun(seed, scenario, condition, path).run()
                if path:
                    compressed = path.with_suffix(".jsonl.gz")
                    with gzip.open(compressed, "wb") as stream:
                        stream.write(path.read_bytes())
                    verified = verify_trace(compressed, result["audit"]["head"])
                    if not verified["valid"]:
                        raise RuntimeError(f"Invalid study trace: {compressed}")
                    if not path.resolve().is_relative_to(trace_root.resolve()):
                        raise RuntimeError("Trace path escaped its output root")
                    path.unlink()
                    result["trace"] = str(compressed.relative_to(trace_root.parent)).replace("\\", "/")
                    result["trace_verification"] = verified
                rows.append(result)
                if progress:
                    progress(len(rows), len(seeds) * len(scenarios) * len(conditions))
    aggregates, paired = [], []
    for scenario in scenarios:
        for condition in conditions:
            selected = [r for r in rows if r["scenario"] == scenario and r["condition"] == condition]
            metrics = {}
            for name in selected[0]["metrics"]:
                values = [r["metrics"][name] for r in selected if r["metrics"][name] is not None]
                metrics[name] = statistics.mean(values) if values else None
            aggregates.append({"scenario": scenario, "condition": condition, "means": metrics})
            if condition != "full" and "full" in conditions:
                for name in ("transfer_error", "late_lag_error", "body_estimate_error", "one_shot_error"):
                    differences = []
                    for row in selected:
                        baseline = next(r for r in rows if r["seed"] == row["seed"] and r["scenario"] == scenario and r["condition"] == "full")
                        value, reference = row["metrics"][name], baseline["metrics"][name]
                        if value is not None and reference is not None:
                            differences.append(value - reference)
                    if differences:
                        paired.append({"scenario": scenario, "condition_minus_full": condition,
                                       "metric": name, **paired_interval(differences)})
    return {"protocol_sha256": hashlib.sha256(PROTOCOL_PATH.read_bytes()).hexdigest(),
            "seeds": seeds, "scenarios": scenarios, "conditions": conditions,
            "run_count": len(rows), "runs": rows, "aggregates": aggregates, "paired_differences": paired,
            "interpretation": "Engineering evidence only; null/contrary effects retained; no consciousness inference."}


def report_markdown(results: dict) -> str:
    lines = ["# AEON developmental perspective: measured results", "",
             f"Runs: {results['run_count']}. Seeds: {', '.join(map(str, results['seeds']))}.", "",
             f"Protocol SHA-256: `{results['protocol_sha256']}`", "",
             "Lower error is better. One-shot success precedes additional motor learning.", "",
             "| Scenario | Configuration | Late lag error | Transfer error | One-shot success | Body estimate error |",
             "| --- | --- | ---: | ---: | ---: | ---: |"]
    for row in results["aggregates"]:
        m = row["means"]
        fmt = lambda name: f"{m[name]:.3f}" if m[name] is not None else "n/a"
        lines.append(f"| {row['scenario']} | {row['condition']} | {fmt('late_lag_error')} | {fmt('transfer_error')} | {fmt('one_shot_success')} | {fmt('body_estimate_error')} |")
    lines += ["", "## Paired comparisons against full entity", "",
              "Positive differences mean the intervention/control had more error. Intervals are descriptive.", "",
              "| Scenario | Control minus full | Metric | Mean difference | Approx. 95% interval |",
              "| --- | --- | --- | ---: | --- |"]
    for row in results["paired_differences"]:
        low, high = row["approx_95_interval"]
        lines.append(f"| {row['scenario']} | {row['condition_minus_full']} | {row['metric']} | {row['mean']:.4f} | [{low:.4f}, {high:.4f}] |")
    lines += ["", "## Interpretation limits", "",
              "This tests a hand-engineered linear world and bounded hypothesis space. Baseline parity or",
              "superiority and null ablations are valid outcomes. Hypothesis scores are heuristic internal",
              "estimates, not calibrated causal probabilities. Computation values use prediction/progress",
              "proxies and shared credit; individual operation benefits are not causally identified.", "",
              "The optional advisor was disabled. These results do not establish subjective experience,",
              "open-ended concept invention, or an independently novel theory of consciousness.", "",
              "See PROTOCOL.md and full per-seed results.json for the design and underlying records.", ""]
    return "\n".join(lines)
