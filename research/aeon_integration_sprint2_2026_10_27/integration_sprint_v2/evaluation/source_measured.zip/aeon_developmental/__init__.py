"""AEON developmental perspective research prototype (standard library only)."""

__version__ = "0.1.0"
