"""World-side laws. Entity inputs deliberately exclude dynamics and interventions."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import math
import random

MAX_DELAY = 3


def noise(seed: int, *coordinates: object) -> float:
    """Counter-keyed draws keep sensory/exogenous noise paired across conditions."""
    digest = hashlib.sha256(repr((seed, coordinates)).encode()).digest()
    return random.Random(int.from_bytes(digest[:8], "big")).gauss(0, 1)


@dataclass(frozen=True)
class Command:
    port: str | None = None
    amount: float = 0.0


@dataclass(frozen=True)
class Percept:
    tick: int
    signals: dict[str, float]
    ports: tuple[str, ...]
    object_id: str
    target_channel: str
    goal: str


class ArmWorld:
    """A small linear arm world, with an independent moving target and distractor.

    No action/sensor name encodes its role. A visual goal can designate a target
    channel; the arm's channels, gain, delay, and tool effects are undisclosed.
    Thinking spends computational credits; only motor steps advance world time.
    """

    def __init__(self, seed: int = 17, scenario: str = "delay", shift: int = 96,
                 transfer: int = 176, donor: bool = False):
        if scenario not in {"delay", "sensor_fault", "world_shift", "action_failure", "tool"}:
            raise ValueError("Unknown scenario")
        self.seed, self.scenario = seed, scenario
        self.shift, self.transfer = shift, transfer
        self.tick = 0
        rng = random.Random(seed)
        channels = [f"s{n:02d}" for n in rng.sample(range(10, 99), 5)]
        self.clean, self.secondary, self.target_channel, self.distractor, self.tool_sensor = channels
        self.motor, self.tool = [f"a{n:02d}" for n in rng.sample(range(10, 99), 2)]
        self.base, self.extension = -0.45, 0.0
        self.target, self.velocity = 0.55, 0.0
        self.gain = -0.11 if donor else 0.16 + 0.01 * (seed % 5)
        self.tool_gain = 0.29
        self.delay = 1 if donor else 0
        self.secondary_offset = 0.0
        self.secondary_noise = 0.015
        self.tool_attached = False
        self.commands: list[Command] = []
        self.events: list[dict] = []
        self.object_id = "object-0"
        self._sample = 0
        self._donor = donor

    @property
    def body(self) -> float:
        return self.base + self.extension

    def observe(self) -> Percept:
        sample = self._sample
        self._sample += 1
        signals = {
            self.clean: self.body + 0.003 * noise(self.seed, self.tick, sample, self.clean),
            self.secondary: self.body + self.secondary_offset + self.secondary_noise * noise(
                self.seed, self.tick, sample, self.secondary),
            self.target_channel: self.target + 0.004 * noise(self.seed, self.tick, sample, self.target_channel),
            self.distractor: 0.4 * math.sin(self.tick * 0.73 + self.seed),
        }
        ports = (self.motor, self.tool) if self.tool_attached else (self.motor,)
        if self.tool_attached:
            signals[self.tool_sensor] = self.extension + 0.004 * noise(
                self.seed, self.tick, sample, self.tool_sensor)
        goal = "explore" if self.tick < self.shift else (
            "intercept" if self.tick >= self.transfer else "reach")
        return Percept(self.tick, signals, ports, self.object_id, self.target_channel, goal)

    def step(self, command: Command) -> None:
        allowed = (self.motor, self.tool) if self.tool_attached else (self.motor,)
        if command.port is not None and command.port not in allowed:
            raise ValueError("Unavailable action port")
        if not math.isfinite(command.amount) or abs(command.amount) > 1.0000001:
            raise ValueError("Action amplitude must be finite and within [-1, 1]")
        self.commands.append(command)
        # A change to latency changes the response filter; no command is relabelled.
        index = len(self.commands) - 1 - self.delay
        if index >= 0:
            executed = self.commands[index]
            if executed.port == self.motor:
                self.base += self.gain * executed.amount
        if command.port == self.tool:
            self.extension += self.tool_gain * command.amount
        self.target += self.velocity
        self.tick += 1
        self._sample = 0
        if self.tick == self.shift and not self._donor:
            if self.scenario == "delay":
                self.delay = 2 + self.seed % 2
            elif self.scenario == "sensor_fault":
                self.secondary_offset = 0.55
                self.secondary_noise = 0.06
            elif self.scenario == "world_shift":
                self.velocity = -0.019
            elif self.scenario == "action_failure":
                self.gain *= 0.3
            elif self.scenario == "tool":
                self.tool_attached = True
            self.events.append({"tick": self.tick, "intervention": self.scenario,
                                "ground_truth": self.truth()})
        if self.tick >= self.transfer and (self.tick - self.transfer) % 16 == 0:
            episode = (self.tick - self.transfer) // 16
            self.object_id = f"object-{episode + 1}"
            self.velocity = (0.022 + 0.003 * (self.seed % 3)) * (-1 if episode % 2 else 1)
            self.target = (-0.55 if episode % 2 == 0 else 0.55)

    def truth(self) -> dict:
        """Evaluator-only state. Never passed to the entity."""
        return {"body": self.body, "target": self.target, "delay": self.delay,
                "gain": self.gain, "body_channels": [self.clean, self.secondary],
                "motor": self.motor, "tool": self.tool, "tool_sensor": self.tool_sensor,
                "tool_attached": self.tool_attached}

    def state(self) -> dict:
        return {**self.__dict__, "commands": [asdict(c) for c in self.commands]}

    @classmethod
    def restore(cls, state: dict) -> "ArmWorld":
        world = cls(state["seed"], state["scenario"], state["shift"], state["transfer"], state["_donor"])
        world.__dict__.update(state)
        world.commands = [Command(**c) for c in state["commands"]]
        return world
