"""Developmental actor: learned perspective -> cognition -> action -> revision."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math
import random
from typing import Callable

from .model import Perspective, clip
from .world import Command, MAX_DELAY, Percept

COSTS = {"observe": 0.6, "retrieve": 0.2, "imagine": 0.45, "consult": 0.9, "act": 0.0}
CONDITIONS = ("full", "frozen_self", "attention_disconnected", "foreign_predictions",
              "memory_loss", "reduced_compute", "simple_controller")
CAUSES = ("stable", "world_changed", "sensor_unreliable", "action_failed", "action_delayed")


@dataclass
class Episode:
    tick: int
    object_id: str
    sensor: str | None
    prediction_error: float
    cause: str
    model_revision: int
    relevance: float = 0.5


@dataclass
class Situation:
    tick: int
    object_id: str
    target_channel: str
    body_channel: str | None
    body_estimate: float
    target_estimate: float
    target_velocity: float
    uncertainty: float
    memory_ticks: list[int]
    intended_command: dict
    relations: list[dict]


class CognitivePolicy:
    """A bounded contextual bandit over computation, updated from sensory scores."""

    def __init__(self):
        self.values: dict[str, dict[str, float]] = {}
        self.counts: dict[str, dict[str, int]] = {}

    def choose(self, context: str, available: list[str], urgency: dict[str, float]) -> tuple[str, dict]:
        values = self.values.setdefault(context, {})
        counts = self.counts.setdefault(context, {})
        total = sum(counts.values()) + 1
        scores = {}
        for operation in available:
            count = counts.get(operation, 0)
            # Uncertainty bonus explores computations; evidence-based urgency is
            # a declared prior, while measured value changes with experience.
            bonus = 0.10 * math.sqrt(math.log(total + 1) / (count + 1))
            scores[operation] = values.get(operation, 0) + urgency.get(operation, 0) + bonus - 0.12 * COSTS[operation]
        scores["act"] = 0.025
        return max(scores, key=scores.get), scores

    def learn(self, context: str, operation: str, benefit: float) -> dict:
        values = self.values.setdefault(context, {})
        counts = self.counts.setdefault(context, {})
        old = values.get(operation, 0)
        counts[operation] = counts.get(operation, 0) + 1
        values[operation] = clip(old + 0.18 * (benefit - old), -0.5, 0.5)
        return {"context": context, "operation": operation, "before": old,
                "after": values[operation], "observed_benefit": benefit}


class DevelopmentalEntity:
    def __init__(self, seed: int = 17, condition: str = "full",
                 advisor: Callable[[dict], dict] | None = None):
        if condition not in CONDITIONS:
            raise ValueError("Unknown condition")
        self.seed, self.condition = seed, condition
        self.rng = random.Random(seed + 4101)
        self.model = Perspective()
        self.foreign: Perspective | None = None
        self.advisor = advisor
        self.cognition = CognitivePolicy()
        self.memory: list[Episode] = []
        self.hypotheses = {cause: 1.0 / len(CAUSES) for cause in CAUSES}
        self.velocity = 0.0
        self.previous: Percept | None = None
        self.last_error = 0.0
        self.last_sensor_conflict = 0.0
        self.probes: list[Command] = []
        self.last_probe_tick = -30
        self.developed_channels: list[str] = []
        self.developed_gains: dict[str, float] = {}
        self.developed_delays: dict[str, int] = {}
        self.developed_velocity = 0.0
        self.locked_sensor: str | None = None
        self.intervened = False
        self.total_cost = 0.0
        self.operation_counts = {name: 0 for name in COSTS}
        self.last_situation: Situation | None = None
        self._pending: dict | None = None

    def intervene(self, foreign: Perspective | None = None) -> None:
        """Research harness intervention, after the same developmental exposure."""
        self.intervened = True
        self.foreign = foreign
        self.developed_velocity = self.velocity
        if self.previous is not None:
            self.developed_channels = self.model.body_channels(self.previous.target_channel)
        if self.developed_channels:
            self.locked_sensor = self.developed_channels[0]
            for port in self.model.ports:
                edge = self.model.connection(port, self.locked_sensor)
                self.developed_gains[port] = edge.gain
                self.developed_delays[port] = edge.delay
        if self.condition == "frozen_self":
            self.model.frozen = True

    def perspective(self) -> Perspective:
        if self.condition == "foreign_predictions" and self.intervened:
            if self.foreign is None:
                raise RuntimeError("Foreign predictions require a separately trained donor")
            # The donor's past actions are not the recipient's pending actions.
            self.foreign.history = self.model.history[:]
            return self.foreign
        return self.model

    def body(self, percept: Percept) -> tuple[float, str | None]:
        model = self.perspective()
        if self.condition == "attention_disconnected" and self.intervened and self.developed_channels:
            sensors = [s for s in self.developed_channels if s in percept.signals]
            return sum(percept.signals[s] for s in sensors) / len(sensors), sensors[0]
        if self.condition == "simple_controller" and self.locked_sensor in percept.signals:
            return percept.signals[self.locked_sensor], self.locked_sensor
        return model.estimate_body(percept)

    def _memory(self, percept: Percept) -> list[Episode]:
        if self.condition == "memory_loss":
            self.memory.clear()
            return []
        # Relevance is itself revised by subsequent prediction outcomes.
        return sorted(self.memory, key=lambda e: e.relevance * (
            1.5 if e.object_id == percept.object_id else 1.0) / (1 + 0.015 * (percept.tick - e.tick)),
            reverse=True)[:3]

    def _diagnostic(self, percept: Percept, sensor: str | None) -> tuple[Command, dict] | None:
        if self.condition == "simple_controller":
            return None
        model = self.perspective()
        unknown = [p for p in percept.ports if sensor is None or p not in model.ports or
                   model.connection(p, sensor).confidence < 0.33]
        surprise = self.last_error > 0.065 and self.last_sensor_conflict < 0.13
        if not self.probes and (unknown or surprise) and percept.tick - self.last_probe_tick > 9:
            port = unknown[-1] if unknown else percept.ports[0]
            # Each candidate explanation predicts a different pulse response.
            # Choose a signed experiment maximizing variance of predicted traces.
            gain = model.connection(port, sensor).gain if sensor and port in model.ports else 0.16
            old_delay = model.connection(port, sensor).delay if sensor and port in model.ports else 0
            experiments = []
            for amount in (-0.8, -0.4, 0.4, 0.8):
                predictions = []
                for cause in ("world_changed", "sensor_unreliable", "action_failed", "action_delayed"):
                    lag = min(MAX_DELAY, old_delay + 2) if cause == "action_delayed" else old_delay
                    response = [0.0] * (MAX_DELAY + 1)
                    response[lag] = gain * amount * (0.25 if cause == "action_failed" else 1.0)
                    predictions.append(response)
                mean = [sum(row[i] for row in predictions) / len(predictions) for i in range(MAX_DELAY + 1)]
                information = sum((row[i] - mean[i]) ** 2 for row in predictions for i in range(MAX_DELAY + 1))
                experiments.append((information - 0.0001 * abs(amount), amount, predictions))
            best = max(experiments, key=lambda e: e[0])
            amount = best[1] * (-1 if self.rng.random() < 0.5 else 1)
            self.probes = [Command(port, amount)] + [Command()] * (MAX_DELAY + 1)
            self.last_probe_tick = percept.tick
            reason = {"reason": "distinguish response gain and latency", "port": port,
                      "predicted_information": best[0],
                      "alternative_response_traces": [[x * amount / best[1] for x in row] for row in best[2]]}
        else:
            reason = {"reason": "finish diagnostic response observation"}
        if self.probes:
            return self.probes.pop(0), reason
        return None

    def _plan(self, percept: Percept, situation: Situation, imagine: bool) -> tuple[Command, dict]:
        model = self.perspective()
        body, sensor = situation.body_estimate, situation.body_channel
        if sensor is None:
            return Command(percept.ports[0], self.rng.choice((-0.8, 0.8))), {"unidentified_body": True}
        target = situation.target_estimate
        candidates = []
        for port in percept.ports:
            if port not in model.ports:
                continue
            edge = model.connection(port, sensor)
            if abs(edge.gain) < 0.025:
                continue
            horizon = edge.delay + 1
            pending = 0.0
            if imagine:
                for other_port in model.ports:
                    other = model.connection(other_port, sensor)
                    for step in range(horizon):
                        index = other.delay - step - 1
                        if 0 <= index < len(model.history):
                            command = model.history[-1 - index]
                            if command.port == other_port:
                                pending += other.gain * command.amount
            expected_target = target + (situation.target_velocity * horizon if imagine else 0)
            amount = clip((expected_target - body - pending) / edge.gain, -1, 1)
            expected_body = body + pending + edge.gain * amount
            risk = abs(expected_body - expected_target) + 0.002 * abs(amount) + 0.008 * (1 - edge.confidence)
            candidates.append((risk, Command(port, amount), {
                "body_channel": sensor, "horizon": horizon, "gain": edge.gain,
                "delay": edge.delay, "pending_displacement": pending,
                "expected_body": expected_body, "expected_target": expected_target,
                "prediction_revision": model.revision, "imagined": imagine}))
        if not candidates:
            return Command(percept.ports[0], self.rng.choice((-0.8, 0.8))), {"unidentified_effect": True}
        _, command, prediction = min(candidates, key=lambda row: row[0])
        return command, prediction

    def decide(self, percept: Percept, observe_again: Callable[[], Percept]) -> dict:
        self.model.register(percept)
        if self.previous is None or self.previous.object_id != percept.object_id:
            self.velocity = 0.0
        body, sensor = self.body(percept)
        target = percept.signals[percept.target_channel]
        uncertain = sensor is None or self.last_error > 0.04
        context = ("uncertain" if uncertain else "calibrated") + (
            ":moving" if abs(self.velocity) > 0.009 else ":still") + (
            ":conflict" if self.last_sensor_conflict > 0.10 else "")
        budget = 0.0 if self.condition == "reduced_compute" else 1.05
        costs = 0.0
        operations = []
        scores = {}
        retrieved: list[Episode] = []
        imagine = self.condition == "simple_controller"
        before_prediction = target
        observations = [percept]
        if self.condition != "simple_controller":
            available = ["observe", "retrieve", "imagine"]
            if self.advisor is not None:
                available.append("consult")
            for _ in range(2):
                available = [op for op in available if COSTS[op] <= budget - costs]
                model = self.perspective()
                lag = model.connection(percept.ports[0], sensor).delay if sensor else 0
                urgency = {
                    "observe": 0.11 if self.last_sensor_conflict > 0.10 or sensor is None else 0,
                    "retrieve": 0.08 if uncertain and self.memory else 0,
                    "imagine": 0.14 if lag > 0 or abs(self.velocity) > 0.009 else 0.01,
                }
                operation, scores = self.cognition.choose(context, available, urgency)
                if operation == "act":
                    break
                available.remove(operation)
                costs += COSTS[operation]
                self.operation_counts[operation] += 1
                if operation == "observe":
                    extra = observe_again()
                    observations.append(extra)
                    # Same-time observations reduce independent sensor noise.
                    percept = Percept(percept.tick, {s: (percept.signals[s] + extra.signals[s]) / 2
                                                    for s in percept.signals}, percept.ports,
                                      percept.object_id, percept.target_channel, percept.goal)
                    body, sensor = self.body(percept)
                elif operation == "retrieve":
                    retrieved = self._memory(percept)
                    # Reuse past diagnostic response length; never read world labels.
                    if any(e.cause == "action_delayed" for e in retrieved):
                        imagine = True
                elif operation == "imagine":
                    imagine = True
                elif operation == "consult":
                    advice = self.advisor({"hypotheses": dict(self.hypotheses),
                                           "perspective": self.model.export(), "credits": budget - costs})
                    # An advisor can suggest extra calculation, never raw motor commands.
                    imagine = imagine or advice.get("operation") == "imagine"
                operations.append(operation)
        uncertainty = 1.0 if sensor is None else math.sqrt(self.perspective().regressions[sensor].residual)
        relations = [{"subject": percept.object_id, "relation": "observed_by", "object": percept.target_channel},
                     {"subject": "intention", "relation": "targets", "object": percept.object_id},
                     {"subject": "prediction", "relation": "uses_perspective_revision", "object": self.perspective().revision}]
        if sensor:
            relations.append({"subject": sensor, "relation": "estimates_body_for", "object": percept.ports[0]})
            if self.last_error > 0.04:
                relations.append({"subject": "prediction", "relation": "contradicted_by", "object": sensor})
        for episode in retrieved:
            relations.append({"subject": f"memory:{episode.tick}", "relation": "informs_uncertainty_of", "object": sensor})
        # Planning consumes this shared situation, before the decision is made.
        self.last_situation = Situation(percept.tick, percept.object_id, percept.target_channel, sensor,
                                        body, percept.signals[percept.target_channel], self.velocity, uncertainty,
                                        [e.tick for e in retrieved], {}, relations)
        if percept.goal == "explore":
            # Bounded endogenous exploration, independent of hidden world parameters.
            command = Command(self.rng.choice(percept.ports), self.rng.choice((-1.0, -0.6, 0.0, 0.6, 1.0)))
            prediction = {"exploration": True}
        else:
            diagnostic = self._diagnostic(percept, sensor)
            if diagnostic:
                command, prediction = diagnostic
            else:
                command, prediction = self._plan(percept, self.last_situation, imagine)
        self.operation_counts["act"] += 1
        self.total_cost += costs
        self.last_situation.intended_command = asdict(command)
        self._pending = {"percept": percept, "command": command, "sensor": sensor,
                         "context": context, "operations": operations, "cost": costs,
                         "predicted_deltas": {s: self.perspective().predict(command, s) for s in percept.signals
                                              if s in self.perspective().regressions},
                         "before_target_prediction": before_prediction,
                         "after_target_prediction": percept.signals[percept.target_channel] + (self.velocity if imagine else 0),
                         "body_estimate": body, "retrieved": retrieved}
        return {"command": asdict(command), "operations": operations, "cost": costs,
                "operation_scores": scores, "situation": asdict(self.last_situation),
                "prediction": prediction, "hypotheses_before": dict(self.hypotheses),
                "observations": [asdict(p) for p in observations]}

    def learn(self, after: Percept) -> dict:
        if self._pending is None:
            raise RuntimeError("decide must precede learn")
        pending = self._pending
        before = pending["percept"]
        command = pending["command"]
        residuals = {s: after.signals[s] - before.signals[s] - pending["predicted_deltas"].get(s, 0)
                     for s in before.signals.keys() & after.signals.keys()}
        channels = self.model.body_channels(before.target_channel)
        sensor = pending["sensor"]
        body_error = abs(residuals.get(sensor, 0))
        sensor_conflict = abs(residuals[channels[0]] - residuals[channels[1]]) if len(channels) > 1 else 0
        target_error = 0.0
        if before.object_id == after.object_id:
            target_error = abs(after.signals[after.target_channel] - before.signals[before.target_channel] - self.velocity)
            instantaneous = after.signals[after.target_channel] - before.signals[before.target_channel]
            self.velocity = clip(0.35 * self.velocity + 0.65 * instantaneous, -0.08, 0.08)
        else:
            self.velocity = 0.0
        changes = self.model.learn(before, command, after)
        lag_change = 0
        gain_change = 0.0
        if sensor and sensor in self.model.regressions:
            edge = self.model.connection(self.model.ports[0], sensor)
            lag_change = abs(edge.delay - self.developed_delays.get(edge.port, edge.delay))
            old_gain = self.developed_gains.get(edge.port, edge.gain)
            gain_change = max(0, 1 - abs(edge.gain) / max(0.025, abs(old_gain)))
        features = {
            "stable": 2.2 - min(4, body_error * 25 + sensor_conflict * 12 + target_error * 25),
            # Compare current motion with the developmental reference as well
            # as transient error: rapid tracking must not erase the explanation
            # before an external change can be recognized.
            "world_changed": -0.5 + min(7, target_error * 90 + abs(self.velocity - self.developed_velocity) * 300),
            "sensor_unreliable": -0.5 + min(7, sensor_conflict * 35),
            "action_failed": -0.8 + min(5, body_error * 20) + 6 * gain_change - min(3, lag_change * 2),
            "action_delayed": -0.8 + min(5, body_error * 20) + min(5, lag_change * 2),
        }
        logits = {cause: 0.45 * math.log(max(1e-6, self.hypotheses[cause])) + value
                  for cause, value in features.items()}
        maximum = max(logits.values())
        normalizer = sum(math.exp(value - maximum) for value in logits.values())
        self.hypotheses = {cause: math.exp(value - maximum) / normalizer for cause, value in logits.items()}
        cause = max(self.hypotheses, key=self.hypotheses.get)
        benefits = []
        if before.object_id == after.object_id:
            observed_target = after.signals[after.target_channel]
            pre_error = abs(observed_target - pending["before_target_prediction"])
            post_error = abs(observed_target - pending["after_target_prediction"])
            progress = abs(before.signals[before.target_channel] - pending["body_estimate"])
            after_body, _ = self.body(after)
            progress -= abs(observed_target - after_body)
            benefit = clip(3 * (pre_error - post_error) + 0.15 * progress, -0.4, 0.4)
            for operation in pending["operations"]:
                # Joint credit is declared: not a causal estimate of each operation's value.
                benefits.append(self.cognition.learn(pending["context"], operation,
                                benefit / max(1, len(pending["operations"])) - 0.12 * COSTS[operation]))
            for episode in pending["retrieved"]:
                episode.relevance = clip(episode.relevance + 0.1 * (benefit - 0.01), 0.05, 1)
        if self.condition != "memory_loss":
            self.memory.append(Episode(after.tick, before.object_id, sensor, body_error, cause, self.model.revision))
            self.memory = self.memory[-48:]
        self.last_error, self.last_sensor_conflict = body_error, sensor_conflict
        self.previous = after
        self._pending = None
        return {"prediction_residuals": residuals, "hypotheses_after": dict(self.hypotheses),
                "evidence": {"body_error": body_error, "sensor_conflict": sensor_conflict,
                             "target_error": target_error, "lag_change": lag_change, "gain_change": gain_change},
                "connection_updates": changes, "perspective": self.model.export(),
                "cognitive_updates": benefits, "memory_size": len(self.memory)}

    def passive_prediction(self, before: Percept) -> None:
        """Prepare a no-command observation interval, without choosing an action."""
        self.model.register(before)
        if self.previous is None or self.previous.object_id != before.object_id:
            self.velocity = 0.0
        body, sensor = self.body(before)
        target = before.signals[before.target_channel]
        self._pending = {"percept": before, "command": Command(), "sensor": sensor,
                         "context": "passive", "operations": [], "cost": 0,
                         "predicted_deltas": {s: self.perspective().predict(Command(), s)
                                              for s in before.signals if s in self.perspective().regressions},
                         "before_target_prediction": target,
                         "after_target_prediction": target + self.velocity,
                         "body_estimate": body, "retrieved": []}

    def state(self) -> dict:
        if self._pending is not None:
            raise RuntimeError("Checkpoint only between committed cycles")
        return {"seed": self.seed, "condition": self.condition, "rng": self.rng.getstate(),
                "model": self.model.state(), "foreign": self.foreign.state() if self.foreign else None,
                "cognition": self.cognition.__dict__, "memory": [asdict(e) for e in self.memory],
                "hypotheses": self.hypotheses, "velocity": self.velocity,
                "previous": asdict(self.previous) if self.previous else None,
                "last_error": self.last_error, "last_sensor_conflict": self.last_sensor_conflict,
                "probes": [asdict(c) for c in self.probes], "last_probe_tick": self.last_probe_tick,
                "developed_channels": self.developed_channels, "developed_gains": self.developed_gains,
                "developed_delays": self.developed_delays, "locked_sensor": self.locked_sensor,
                "developed_velocity": self.developed_velocity,
                "intervened": self.intervened, "total_cost": self.total_cost,
                "operation_counts": self.operation_counts}

    @classmethod
    def restore(cls, state: dict) -> "DevelopmentalEntity":
        def tuples(value):
            return tuple(tuples(v) for v in value) if isinstance(value, list) else value
        entity = cls(state["seed"], state["condition"])
        for name, value in state.items():
            if name not in {"rng", "model", "foreign", "cognition", "memory", "previous", "probes"}:
                setattr(entity, name, value)
        entity.rng.setstate(tuples(state["rng"]))
        entity.model = Perspective.restore(state["model"])
        entity.foreign = Perspective.restore(state["foreign"]) if state["foreign"] else None
        entity.cognition.__dict__.update(state["cognition"])
        entity.memory = [Episode(**e) for e in state["memory"]]
        entity.previous = Percept(**{**state["previous"], "ports": tuple(state["previous"]["ports"])}) if state["previous"] else None
        entity.probes = [Command(**c) for c in state["probes"]]
        return entity
