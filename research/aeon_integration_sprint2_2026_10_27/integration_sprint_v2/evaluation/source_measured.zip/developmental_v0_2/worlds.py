"""Evaluator-owned worlds. Actors receive only observations and action ports."""
from dataclasses import dataclass, asdict
import hashlib
import math
import random
from aeon_developmental.world import noise

FAMILIES = ('nonlinear_gain', 'variable_delay', 'actuator_coupling', 'sensor_dropout', 'correlated_distractor', 'compound')
# These laws are reserved, not constructed or run by the development command.
RESERVED = ('hysteresis', 'state_dependent_delay', 'coupling_dropout_distractor')

@dataclass(frozen=True)
class Observation:
    tick: int
    signals: dict
    ports: tuple
    target_channel: str

class World:
    def __init__(self, seed, family, shift=192):
        if family not in FAMILIES:
            raise ValueError('Development worlds only; reserved families are unavailable')
        self.seed, self.family, self.shift = seed, family, shift
        self.tick, self.body = 0, -0.3
        self.history = []
        rng = random.Random(seed)
        labels = [hashlib.sha256(f'{seed}:opaque:{i}'.encode()).hexdigest()[:12] for i in range(6)]
        rng.shuffle(labels)
        self.sensors, self.target_channel, self.ports = labels[:3], labels[3], tuple(labels[4:])
        self.gains = (0.15 + 0.01*(seed % 4), -0.12 - 0.01*(seed % 3))

    def target(self):
        return 0.55*math.sin(0.035*self.tick + self.seed*0.13) + 0.18*math.sin(0.087*self.tick)

    def observe(self):
        s = {self.sensors[0]: self.body + 0.004*noise(self.seed,self.tick,'sensor0'),
             self.sensors[1]: self.body + 0.015*noise(self.seed,self.tick,'sensor1'),
             self.sensors[2]: 0.5*math.sin(0.17*self.tick + self.seed),
             self.target_channel: self.target() + 0.004*noise(self.seed,self.tick,'target')}
        if self.tick >= self.shift:
            if self.family in ('sensor_dropout','compound'):
                # Intermittent omission, not a zero reading or fault label.
                if self.tick % 29 < 19:
                    s.pop(self.sensors[0])
                s[self.sensors[1]] += 0.025*noise(self.seed,self.tick,'degraded')
            if self.family == 'correlated_distractor':
                s[self.sensors[2]] = self.body + 0.35 + 0.12*math.sin(self.tick*0.08)
        return Observation(self.tick, s, self.ports, self.target_channel)

    def step(self, action):
        if len(action) != 2 or any(not math.isfinite(v) or abs(v)>1 for v in action) or sum(abs(v)>1e-12 for v in action)>1:
            raise ValueError('Choose at most one bounded actuator per tick')
        changed = self.tick >= self.shift
        delay = 0
        if changed and self.family in ('variable_delay','compound'):
            delay = (1,3,2)[((self.tick-self.shift)//32) % 3]
        self.history.append(list(action))
        index = len(self.history)-1-delay
        u = self.history[index] if index>=0 else [0.,0.]
        prior = self.history[index-1] if index>0 else [0.,0.]
        gain = self.gains
        if changed and self.family in ('nonlinear_gain','compound'):
            effect = sum(gain[j]*(0.35*u[j]+0.65*u[j]**3) for j in range(2))
        else:
            effect = sum(gain[j]*u[j] for j in range(2))
        if changed and self.family in ('actuator_coupling','compound'):
            effect += 0.16*(u[0]*prior[1]-u[1]*prior[0])
        self.body += effect + 0.001*noise(self.seed,self.tick,'external')
        self.tick += 1
        self.history = self.history[-8:]

    def state(self):
        return dict(self.__dict__)

    @classmethod
    def restore(cls, state):
        w=cls(state['seed'],state['family'],state['shift'])
        w.__dict__.update(state)
        w.ports=tuple(w.ports)
        return w
