"""Learned sensor/action perspective and matched-information adaptive baseline.

No world objects, seeds, family identifiers, evaluator state or callbacks enter
Actor. The pilot isolates dynamic attention + shared prediction-to-planner use;
it is not the entire earlier modular AEON architecture.
"""
import copy
import numpy as np
from .worlds import Observation

CONDITIONS=('full','adaptive_baseline','frozen_perspective','planner_disconnected')
WARMUP=128
LAGS=5
DIM=1+LAGS*7
CANDIDATES=np.array([[0.,0.]]+[[v if j==p else 0. for j in range(2)] for p in range(2) for v in (-1.,-.75,-.5,-.25,.25,.5,.75,1.)])

def features(action, history):
    h=[list(action)]+list(reversed(history))
    out=[1.]
    for lag in range(LAGS):
        u=h[lag] if lag<len(h) else [0.,0.]
        prev=h[lag+1] if lag+1<len(h) else [0.,0.]
        out.extend([u[0],u[1],u[0]**3,u[1]**3,np.tanh(2*u[0]),np.tanh(2*u[1]),u[0]*prev[1]-u[1]*prev[0]])
    return np.array(out)

class Regression:
    def __init__(self):
        self.w=np.zeros(DIM)
        self.p=np.eye(DIM)*20.
        self.error=0.01
        self.count=0
    def update(self,x,y):
        residual=float(y-x@self.w)
        self.error=.94*self.error+.06*min(1.,residual**2)
        px=self.p@x
        k=px/(.975+x@px)
        self.w+=k*residual
        self.p=(self.p-np.outer(k,px))/.975
        self.p=(self.p+self.p.T)*.5
        self.count+=1
    def state(self):
        return {'w':self.w.tolist(),'p':self.p.tolist(),'error':self.error,'count':self.count}
    @classmethod
    def restore(cls,d):
        r=cls(); r.w=np.array(d['w']); r.p=np.array(d['p']); r.error=d['error'];r.count=d['count'];return r

class Actor:
    def __init__(self, condition):
        if condition not in CONDITIONS: raise ValueError(condition)
        self.condition=condition
        self.models={}
        self.history=[]
        self.members=[]
        self.locked=None
        self.planner_weights={}
        self.previous=None
        self.pending=None
        self.velocity=0.
        self.last_body=0.
        self.last_delta=0.
        self.revision=0
        self.model_updates=0
        self.prediction_evaluations=0
        self.episodes=[]

    def establish_members(self,target):
        # Common acquisition: controllability excludes an initially autonomous distractor.
        scores={s:float(np.linalg.norm(r.w[1:]))/(.01+np.sqrt(r.error)) for s,r in self.models.items() if s!=target}
        self.members=sorted(scores,key=scores.get,reverse=True)[:2]
        self.locked=min(self.members,key=lambda s:self.models[s].error)
        self.planner_weights={s:r.w.copy() for s,r in self.models.items()}

    def decide(self,obs):
        if self.pending is not None: raise RuntimeError('Feedback required before another action')
        for s in obs.signals: self.models.setdefault(s,Regression())
        if obs.tick==WARMUP: self.establish_members(obs.target_channel)
        if self.previous:
            self.velocity=float(np.clip(.5*self.velocity+.5*(obs.signals[obs.target_channel]-self.previous.signals[obs.target_channel]),-.1,.1))
        available=[s for s in self.members if s in obs.signals]
        if available:
            if self.condition=='adaptive_baseline':
                # Simple adaptive MPC: retain lowest-noise calibration channel, fallback when absent.
                selected=self.locked if self.locked in available else available[0]
                weights={selected:1.}
            else:
                raw={s:1/(1e-5+self.models[s].error) for s in available}
                weights={s:v/sum(raw.values()) for s,v in raw.items()}
            body=sum(weights[s]*obs.signals[s] for s in weights)
        else:
            weights={}
            body=self.last_body+self.last_delta
        if obs.tick<WARMUP:
            # Same deterministic excitation for every actor, independent of family and change time.
            p=obs.tick%2
            amount=(-1.,-.5,.5,1.)[((obs.tick//2)*7+obs.tick//11)%4]
            action=np.array([amount if j==p else 0. for j in range(2)])
            rollouts=0
        else:
            # Identical receding-horizon candidate search for all four configurations.
            bank=self.planner_weights if self.condition=='planner_disconnected' else {s:r.w for s,r in self.models.items()}
            w=sum((weights[s]*bank[s] for s in weights),np.zeros(DIM))
            positions=np.full(len(CANDIDATES),body)
            scores=np.zeros(len(CANDIDATES))
            histories=[self.history[:] for _ in CANDIDATES]
            target=obs.signals[obs.target_channel]
            for horizon in range(LAGS):
                actions=CANDIDATES if horizon==0 else np.zeros_like(CANDIDATES)
                xx=np.stack([features(a,h) for a,h in zip(actions,histories)])
                positions+=np.clip(xx@w,-.6,.6)
                scores+=(positions-(target+self.velocity*(horizon+1)))**2
                for h,a in zip(histories,actions): h.append(list(a)); h[:]=h[-LAGS:]
            scores+=.002*np.sum(CANDIDATES**2,axis=1)
            action=CANDIDATES[int(np.argmin(scores))].copy()
            rollouts=len(CANDIDATES)*LAGS
            self.prediction_evaluations+=rollouts
        x=features(action,self.history)
        predicted={s:float(x@r.w) for s,r in self.models.items() if s in obs.signals}
        self.last_body=float(body)
        self.last_delta=sum(weights[s]*predicted[s] for s in weights)
        self.pending=(obs,action.tolist(),x,predicted)
        return {'action':action.tolist(),'prediction':predicted,'body_estimate':float(body),
                'attention':weights,'revision':self.revision,'planner_frozen':self.condition=='planner_disconnected',
                'rollout_predictions':rollouts}

    def learn(self,after):
        if self.pending is None: raise RuntimeError('Decision must precede feedback')
        before,action,x,predicted=self.pending
        residuals={s:after.signals[s]-before.signals[s]-predicted[s] for s in before.signals.keys() & after.signals.keys()}
        frozen=self.condition=='frozen_perspective' and before.tick>=WARMUP
        if not frozen:
            for s in sorted(residuals):
                self.models[s].update(x,after.signals[s]-before.signals[s])
                self.model_updates+=1
            self.revision+=1
        self.history.append(action);self.history=self.history[-LAGS:]
        self.previous=before
        self.episodes.append({'tick':before.tick,'residuals':residuals,'revision':self.revision})
        self.episodes=self.episodes[-32:]
        self.pending=None
        return residuals

    def state(self):
        if self.pending is not None: raise RuntimeError('Checkpoint only after feedback')
        from dataclasses import asdict
        d=copy.deepcopy(self.__dict__)
        d['models']={s:r.state() for s,r in self.models.items()}
        d['planner_weights']={s:w.tolist() for s,w in self.planner_weights.items()}
        d['previous']=asdict(self.previous) if self.previous else None
        return d

    @classmethod
    def restore(cls,d):
        a=cls(d['condition']);a.__dict__.update(copy.deepcopy(d))
        a.models={s:Regression.restore(r) for s,r in d['models'].items()}
        a.planner_weights={s:np.array(w) for s,w in d['planner_weights'].items()}
        a.previous=Observation(**d['previous']) if d['previous'] else None
        return a
