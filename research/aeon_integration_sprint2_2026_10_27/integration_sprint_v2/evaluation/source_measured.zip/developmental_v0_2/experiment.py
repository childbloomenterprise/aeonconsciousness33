"""Frozen pilot runner, committed traces and paired analysis."""
import argparse
from dataclasses import asdict
import gzip
import hashlib
import json
from pathlib import Path
import platform
import time
import traceback
import numpy as np
from aeon_developmental.experiment import canonical, digest, verify_trace
from .worlds import World, FAMILIES, RESERVED
from .actors import Actor, CONDITIONS

SEEDS=(301,307,311,313,317,331,337,347,349,353)
TICKS=384

class Trace:
    def __init__(self,path=None):
        self.head='0'*64; self.count=0
        self.stream=gzip.open(path,'wt',encoding='utf-8') if path else None
    def append(self,event):
        row={'index':self.count,'previous':self.head,'event':event};row['hash']=digest(row)
        if self.stream:
            self.stream.write(canonical(row)+'\n');self.stream.flush()
        self.head=row['hash'];self.count+=1
    def close(self):
        if self.stream:self.stream.close()

class Run:
    def __init__(self,seed,family,condition,trace=None):
        self.world=World(seed,family);self.actor=Actor(condition)
        self.obs=self.world.observe();self.metrics=[];self.trace=Trace(trace)
        self.actor_wall=0.;self.actor_cpu=0.
    def cycle(self):
        t=time.perf_counter();c=time.process_time()
        decision=self.actor.decide(self.obs)
        self.actor_wall+=time.perf_counter()-t;self.actor_cpu+=time.process_time()-c
        self.trace.append({'type':'decision','observation':asdict(self.obs),'actor':decision})
        self.world.step(decision['action'])
        after=self.world.observe()
        t=time.perf_counter();c=time.process_time()
        residuals=self.actor.learn(after)
        self.actor_wall+=time.perf_counter()-t;self.actor_cpu+=time.process_time()-c
        error=self.world.body-self.world.target()
        m={'tick':self.world.tick,'squared_error':error**2,'success':abs(error)<=.08,
           'energy':sum(x*x for x in decision['action'])}
        self.metrics.append(m)
        self.trace.append({'type':'outcome','percept':asdict(after),'learning':{'residuals':residuals,'revision':self.actor.revision},
                           'evaluator_only':{'body':self.world.body,'target':self.world.target(),'metric':m}})
        self.obs=after
    def state(self):
        return {'world':self.world.state(),'actor':self.actor.state(),'obs':asdict(self.obs),'metrics':self.metrics}
    def checkpoint(self,path):
        state=self.state();path.write_text(canonical({'payload':state,'sha256':digest(state)}))
    @classmethod
    def restore(cls,path):
        envelope=json.loads(path.read_text());s=envelope['payload']
        if digest(s)!=envelope['sha256']:raise ValueError('Checkpoint hash mismatch')
        r=cls.__new__(cls);r.world=World.restore(s['world']);r.actor=Actor.restore(s['actor'])
        from .worlds import Observation
        r.obs=Observation(**s['obs']);r.metrics=s['metrics'];r.trace=Trace();r.actor_wall=0.;r.actor_cpu=0.;return r
    def finish(self):
        start=time.perf_counter()
        while self.world.tick<TICKS:self.cycle()
        post=[r for r in self.metrics if r['tick']>self.world.shift]
        pre=[r for r in self.metrics if 128<r['tick']<=self.world.shift]
        self.trace.close()
        return {'seed':self.world.seed,'family':self.world.family,'condition':self.actor.condition,
                'loss':sum(r['squared_error'] for r in post),'post_samples':len(post),
                'pre_success':float(np.mean([r['success'] for r in pre])),
                'energy':sum(r['energy'] for r in self.metrics),'actor_wall_seconds':self.actor_wall,
                'actor_cpu_seconds':self.actor_cpu,'elapsed_seconds':time.perf_counter()-start,
                'model_updates':self.actor.model_updates,'prediction_evaluations':self.actor.prediction_evaluations,
                'observations':len(self.metrics)+1,'actions':len(self.metrics),
                'state_sha256':digest(self.state()),'trace_head':self.trace.head,'trace_records':self.trace.count}

def interval(a,b):
    # Inputs already averaged over the fixed world suite within each seed.
    a=np.array(a);b=np.array(b);rng=np.random.default_rng(90210)
    idx=rng.integers(0,len(a),size=(10000,len(a)))
    diff=(b[idx]-a[idx]).mean(axis=1)
    return {'control_minus_full':float(np.mean(b-a)),
            'ci95':np.quantile(diff,[.025,.975]).tolist(),
            'reduction_percent':100*float(np.mean(b-a)/np.mean(b)) if np.mean(b)>1e-9 else None}

def analyze(rows):
    families=[]
    for f in FAMILIES:
        means={c:float(np.mean([r['loss'] for r in rows if r['family']==f and r['condition']==c])) for c in CONDITIONS}
        a=[next(r['loss'] for r in rows if r['family']==f and r['seed']==s and r['condition']=='full') for s in SEEDS]
        comparisons={}
        for c in CONDITIONS[1:]:
            b=[next(r['loss'] for r in rows if r['family']==f and r['seed']==s and r['condition']==c) for s in SEEDS]
            comparisons[c]=interval(a,b)
        families.append({'family':f,'means':means,'comparisons':comparisons})
    block={c:[float(np.mean([r['loss'] for r in rows if r['seed']==s and r['condition']==c])) for s in SEEDS] for c in CONDITIONS}
    aggregate={c:interval(block['full'],block[c]) for c in CONDITIONS[1:]}
    regression=100*(np.mean([r['pre_success'] for r in rows if r['condition']=='adaptive_baseline'])-np.mean([r['pre_success'] for r in rows if r['condition']=='full']))
    primary=aggregate['adaptive_baseline']
    return {'families':families,'aggregate':aggregate,'retention_success_regression_pp':float(regression),
            'adaptation_gate':primary['reduction_percent'] is not None and primary['reduction_percent']>=15 and primary['ci95'][0]>0,
            'retention_proxy_gate':bool(regression<=5),
            'compute':{c:{k:float(np.mean([r[k] for r in rows if r['condition']==c])) for k in ('actor_wall_seconds','actor_cpu_seconds','model_updates','prediction_evaluations','energy')} for c in CONDITIONS}}

def report(result):
    a=result['analysis'];p=a['aggregate']['adaptive_baseline']
    lines=['# AEON Stage B: 240-run development pilot','',
           '26 October 2026. Executed numerical experiments; no LLM used in action or learning.','',
           f"Completed {len(result['runs'])}/240 runs. Reference reproduction is in reference/reproduction.json.",'',
           f"Full vs adaptive baseline loss reduction: {p['reduction_percent']:.2f}% (negative means worse).",
           f"Paired control-minus-full loss: {p['control_minus_full']:.6f}; 95% seed-block bootstrap interval {p['ci95']}.",
           f"Prospective 15% adaptation gate: {'PASS' if a['adaptation_gate'] else 'NOT MET'}.",'',
           '| World family | Full | Adaptive baseline | Frozen | Planner disconnected |',
           '| --- | ---: | ---: | ---: | ---: |']
    for f in a['families']:
        lines.append('| '+f['family']+' | '+' | '.join(f"{f['means'][c]:.4f}" for c in CONDITIONS)+' |')
    lines+=['','Values are mean cumulative squared task error over the 192 post-change actions; lower is better.','',
            '## What was implemented','',
            'A separate focused v0.2 numerical perspective, nonlinear online prediction, two actuators, learned body sensor membership, dynamic reliability weighting and five-step planning. The baseline has the same model capacity and planning horizon with a simpler fixed preferred sensor plus missing-sensor fallback. Frozen and planner-disconnection controls intervene after shared acquisition, 64 ticks before the hidden change.',
            '', 'This does not integrate the earlier global workspace, REG-012 or metacognitive runtime. Episodic residuals are bounded records, not a demonstrated memory mechanism.', '',
            '## Resources and retention proxy','',
            '| Configuration | Mean actor wall seconds/run | Mean actor CPU seconds/run | Model updates/run | Predicted rollout steps/run |',
            '| --- | ---: | ---: | ---: | ---: |']
    for c,m in a['compute'].items():
        lines.append(f"| {c} | {m['actor_wall_seconds']:.3f} | {m['actor_cpu_seconds']:.3f} | {m['model_updates']:.0f} | {m['prediction_evaluations']:.0f} |")
    lines += ['',f"Pre-change success regression vs baseline: {a['retention_success_regression_pp']:.2f} percentage points.",
              'All configurations receive 385 observations and 384 action opportunities. CPU is measured, not matched; prediction counts exclude feature arithmetic. World simulation and trace I/O are outside actor timings.', '',
              '## Evidence and interpretation','',
              'Each trace commits predictions before action execution. All 240 compressed chains are checked against recorded heads. Sources and protocol were hashed before the first pilot run. The runner rejects existing output directories and records failures without replacement.',
              'The confidence interval resamples ten paired seed blocks across the six fixed families; it is not evidence about all possible worlds. Per-family and ablation comparisons are exploratory, without multiplicity correction.',
              'The held-out hysteresis, state-dependent-delay and coupling/dropout/distractor families were not generated or run. A future confirmatory benchmark still needs its own frozen specification.', '',
              'A failed gate means revise or simplify before scaling. A passed pilot gate would justify a separate confirmation, not a claim of consciousness or superiority of the entire AEON architecture.', '',
              '## Reproduce','',
              '```powershell','python -m unittest test_developmental test_developmental_v02 -q',
              'python -m developmental_v0_2.experiment --out pilot_evidence/new_pilot','```','',
              'NumPy is required for v0.2. Original aeon_developmental sources are unchanged. See PROTOCOL.md, results.json, traces, and the reference archive for inspectable evidence.','']
    return '\n'.join(lines)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    reference=Path('pilot_evidence/reference/reproduction.json')
    if not reference.exists():raise SystemExit('Finish reference reproduction first')
    repro=json.loads(reference.read_text())
    if repro['metric_matches']!=repro['count']:raise SystemExit('Reference qualification failed')
    args.out.mkdir(parents=True,exist_ok=False)
    sources=sorted(Path('developmental_v0_2').glob('*.py'))+[Path('developmental_v0_2/PROTOCOL.md'),Path('test_developmental_v02.py')]
    manifest={'files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
              'python':platform.python_version(),'numpy':np.__version__,'seeds':SEEDS,'reserved_unrun':RESERVED}
    (args.out/'source_manifest.json').write_text(json.dumps(manifest,indent=2))
    traces=args.out/'traces';traces.mkdir()
    rows=[];failures=[]
    for f in FAMILIES:
        for s in SEEDS:
            for c in CONDITIONS:
                path=traces/f'{f}_{s}_{c}.jsonl.gz'
                run=None
                try:
                    run=Run(s,f,c,path);r=run.finish()
                    v=verify_trace(path,r['trace_head'])
                    if not v['valid']:raise RuntimeError('Invalid trace')
                    r['trace']=path.name;r['trace_verified']=True;rows.append(r)
                except Exception:
                    if run:run.trace.close()
                    failures.append({'family':f,'seed':s,'condition':c,'error':traceback.format_exc()})
                (args.out/'progress.json').write_text(json.dumps({'completed':len(rows),'failures':failures}))
        print(f'{f}: {len(rows)} completed, {len(failures)} failed',flush=True)
    result={'runs':rows,'failures':failures,'analysis':analyze(rows) if not failures else None,'manifest':manifest}
    (args.out/'results.json').write_text(json.dumps(result,indent=2))
    if failures:raise SystemExit('Incomplete pilot; failures retained')
    (args.out/'RESULTS.md').write_text(report(result),encoding='utf-8')
    print(json.dumps(result['analysis']['aggregate'],indent=2),flush=True)
if __name__=='__main__':main()
