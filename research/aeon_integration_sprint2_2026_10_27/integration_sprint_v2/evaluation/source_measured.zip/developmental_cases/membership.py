"""Membership repair: observation agreement, not prediction residual, finds redundancy."""
import copy
from dataclasses import asdict
import json
import time
from pathlib import Path
import numpy as np
from developmental_v0_2.actors import Actor,WARMUP
from developmental_v0_2.experiment import Run
from developmental_v0_2.worlds import World,FAMILIES
from aeon_developmental.experiment import canonical
from .common import Evidence

class ValidatedActor(Actor):
    def __init__(self):
        super().__init__('adaptive_baseline')
        self.calibration=[]
    def decide(self,obs):
        if obs.tick<WARMUP:self.calibration.append(dict(obs.signals))
        return super().decide(obs)
    def establish_members(self,target):
        super().establish_members(target)
        sensors=[s for s in self.models if s!=target]
        pairs=[]
        for i,a in enumerate(sensors):
            for b in sensors[i+1:]:
                rows=[(r[a],r[b]) for r in self.calibration if a in r and b in r]
                x,y=np.array(rows).T
                agreement=float(np.sqrt(np.mean((x-y)**2)))
                # Genuine redundancy must match absolute position, not just correlate.
                if agreement<.06:pairs.append((agreement,a,b))
        if pairs:
            _,a,b=min(pairs)
            self.members=[a,b]
            self.locked=min(self.members,key=lambda s:self.models[s].error)
        self.calibration=[]
    @classmethod
    def restore(cls,state):
        a=cls();restored=Actor.restore(state);a.__dict__.update(restored.__dict__);return a

def make_run(seed,family,condition,trace=None):
    r=Run(seed,family,'full' if condition=='full' else 'adaptive_baseline',trace)
    if condition=='validated_membership':r.actor=ValidatedActor()
    return r

def membership_trial(seed,family,condition,path):
    r=make_run(seed,family,condition,path);row=r.finish();row['condition']=condition
    from aeon_developmental.experiment import verify_trace
    row['verified']=verify_trace(path,row['trace_head'])['valid']
    if not row['verified']:raise RuntimeError('Trace integrity failed')
    row['correct_members']=set(r.actor.members)==set(r.world.sensors[:2])
    return row

def continuity_trial(seed,condition,path,ticks=10000,split=5000):
    r=make_run(seed,'compound',condition)
    evidence=Evidence(path)
    restored=None;equivalent=True;bounded=True;finite=True;worst=0.;peak=0
    started=time.perf_counter()
    for tick in range(ticks):
        # Run.cycle commits internal prediction hash before action. This compact
        # exported trace records the same actor decision before applying it.
        decision=r.actor.decide(r.obs);evidence.decision({'tick':tick,**decision})
        r.world.step(decision['action']);after=r.world.observe();r.actor.learn(after);r.obs=after
        if restored is not None:
            d2=restored.actor.decide(restored.obs)
            equivalent &= canonical(decision)==canonical(d2)
            restored.world.step(d2['action']);a2=restored.world.observe();restored.actor.learn(a2);restored.obs=a2
        error=abs(r.world.body-r.world.target());worst=max(worst,error)
        bounded &= len(r.actor.history)<=5 and len(r.actor.episodes)<=32 and len(getattr(r.actor,'calibration',[]))<=128
        finite &= all(np.isfinite(m.w).all() and np.isfinite(m.p).all() for m in r.actor.models.values()) and np.isfinite(error)
        evidence.outcome({'tick':tick+1,'error':error,'finite':bool(finite),'bounded':bool(bounded)})
        if (tick+1)%1000==0:peak=max(peak,len(canonical(r.actor.state())))
        if tick+1==split:
            snapshot={'world':r.world.state(),'actor':r.actor.state(),'observation':asdict(r.obs)}
            raw=canonical(snapshot)
            checkpoint=path.with_suffix('.checkpoint.json');checkpoint.write_text(raw)
            s=json.loads(raw)
            restored=make_run(seed,'compound',condition)
            restored.world=World.restore(s['world'])
            restored.actor=ValidatedActor.restore(s['actor']) if condition=='validated_membership' else Actor.restore(s['actor'])
            from developmental_v0_2.worlds import Observation
            restored.obs=Observation(**s['observation'])
        if not finite:break
    if restored is not None:
        equivalent &= canonical(r.world.state())==canonical(restored.world.state()) and canonical(r.actor.state())==canonical(restored.actor.state())
    return {'seed':seed,'condition':condition,'ticks':r.world.tick,'loss':worst,'worst_tracking_error':worst,
            'exact_continuation':bool(equivalent and restored is not None),'bounded':bool(bounded),'finite':bool(finite),
            'peak_actor_json_bytes':peak,'elapsed_seconds':time.perf_counter()-started,
            'engineering_pass':bool(equivalent and bounded and finite and r.world.tick==ticks),
            'stability_screen':bool(worst<=5),**evidence.close()}
