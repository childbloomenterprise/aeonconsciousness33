"""Common precommitted evidence and paired development analysis."""
import gzip
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from aeon_developmental.experiment import canonical,digest,verify_trace
from developmental_v0_2.experiment import Trace
SEEDS=(501,503,509,521,523,541,547,557,563,569)

def keyed(seed,tick,channel):
    raw=hashlib.sha256(f'{seed}:{tick}:{channel}'.encode()).digest()
    return np.random.default_rng(int.from_bytes(raw[:8],'big')).normal()

def save(path,data):
    Path(path).write_text(json.dumps(data,indent=2,allow_nan=False),encoding='utf-8')

def paired(rows,full,control,metric='loss'):
    seeds=sorted({r['seed'] for r in rows})
    a=[];b=[]
    for s in seeds:
        a.append(np.mean([r[metric] for r in rows if r['seed']==s and r['condition']==full]))
        b.append(np.mean([r[metric] for r in rows if r['seed']==s and r['condition']==control]))
    a=np.array(a);b=np.array(b);idx=np.random.default_rng(81234).integers(0,len(a),(10000,len(a)))
    ci=np.quantile((b[idx]-a[idx]).mean(axis=1),[.025,.975]).tolist()
    return {'control':control,'mean_full':float(a.mean()),'mean_control':float(b.mean()),
            'control_minus_full':float((b-a).mean()),'ci95':ci,
            'improvement_percent':float(100*(b-a).mean()/b.mean()) if b.mean()>1e-9 else None}

def comparison(rows,full,controls,gate):
    pairs=[paired(rows,full,c) for c in controls]
    strongest=min(pairs,key=lambda x:x['mean_control'])
    return {'comparisons':pairs,'strongest_control':strongest['control'],
            'gate':strongest['improvement_percent'] is not None and strongest['improvement_percent']>=gate and strongest['ci95'][0]>0}

class Evidence:
    def __init__(self,path):self.path=path;self.trace=Trace(path)
    def decision(self,value):self.trace.append({'type':'decision','actor':value})
    def outcome(self,value):self.trace.append({'type':'outcome','evaluator':value})
    def close(self):
        self.trace.close();v=verify_trace(self.path,self.trace.head)
        if not v['valid']:raise RuntimeError('Trace failed verification')
        return {'trace':self.path.name,'head':self.trace.head,'records':self.trace.count,'verified':True}
