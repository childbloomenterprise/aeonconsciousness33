"""Remaining AEON development cases; isolated numeric mechanisms, no LLMs."""
